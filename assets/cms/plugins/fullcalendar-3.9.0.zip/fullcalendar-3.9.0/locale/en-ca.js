import 'moment/locale/en-ca';
import * as FullCalendar from 'fullcalendar';


FullCalendar.locale("en-ca");
